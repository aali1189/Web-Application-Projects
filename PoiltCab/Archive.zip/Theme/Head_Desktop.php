 
 
  <link href="<?php echo $path[$pathStyleOfPage-2]; ?>Style/css/main.css" rel="stylesheet"/>
  <link href="<?php echo $path[$pathStyleOfPage-2]; ?>Style/css/Form.css" rel="stylesheet"/>
  <link href="<?php echo $path[$pathStyleOfPage-2]; ?>Style/css/top-bar.css" rel="stylesheet"/>
 