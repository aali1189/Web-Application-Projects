<?php
//$Arr =  Get_Menus_All('Title');
?>
<nav class="navbar">
<div class="Container-fluid">
  <div class="navbar-header">
    <ul class="nav nav-tabs">
    <li><a class="navbar-brand" href="?Action=Flights"><i style="font-size: 36px;transform: rotate(
327deg);" class="fas fa-plane"></i><p>Flights</p></a>
    </li>
    <li>
      <a class="navbar-brand" href="?Action=Holtels"><i style="font-size: 36px;" class="fas fa-hotel"></i><p>Hotels</p></a>
    </li>
     <li>
      <a class="navbar-brand" href="?Action=Car"><i style="font-size: 36px;" class="fas fa-car"></i><p>Rental Car</p></a>
    </li>
    
  </ul>
  </div>
</div>
</nav>
