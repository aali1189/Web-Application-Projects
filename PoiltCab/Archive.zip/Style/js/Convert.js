function convert(){
   var Amount = document.getElementById("Amount").value; 
    
    
}