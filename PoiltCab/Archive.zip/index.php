<?php

include('Theme/Header.php');



//$Name = $_GET['Action'];
//
//if($_GET['Action'] == null){
//    
//header("Location: http://".$_SERVER['HTTP_HOST'] . "/".$Project_Path."/?Name=Flights");
//}
//    

include('Theme/Body.php');
include('Theme/Footer.php');

 ?>
