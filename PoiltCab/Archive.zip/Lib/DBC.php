<?php

$con = mysqli_connect("localhost","root", "rootroot", "Lazurd");
