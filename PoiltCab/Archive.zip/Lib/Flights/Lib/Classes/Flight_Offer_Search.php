<?php

include('Core.php');

class Flights extends Flight {
    //include '';
    function Search_One_Way($Arr){
        
      $Request_Flight = new Flight();
      return  $Request_Flight->FOS($Arr);
    
    }
    
//$Origin, $Destination, $Departure, $Return ,$Adults, $Children, $Infants, $TravelClass, $IncludedAirlineCodes, $NonStop, $CurrencyCode, $MaxPrice, $MaxOfResult
    
    function Search_Round_Trip($Arr){
        
        $Request_Flight = new Flight();
        return $Request_Flight->Request($Arr); 
        
    }
    
//$Origin, $Destination, $Departure, $Return ,$Adults, $Children, $Infants, $TravelClass, $IncludedAirlineCodes, $NonStop, $CurrencyCode, $MaxPrice, $MaxOfResult
    
    
    function Search_Multi_City($Arr){
        
        $Request_Flight = new Flight();
        return $Request_Flight->Request($Arr);   
        
    }
    
    
    
}

?>