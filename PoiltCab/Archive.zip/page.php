<?php
include('Theme/Header.php');

include('Theme/Footer.php');

 ?>