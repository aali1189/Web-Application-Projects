<?php 


include('Theme/Header.php');

echo "Hours : " . CalculateHours("05:10","02:30");


?>